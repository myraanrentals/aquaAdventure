import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Lightbox } from 'ngx-lightbox';
import { MainService } from 'src/app/services/main.service';

@Component({
  selector: 'app-watersports',
  templateUrl: './watersports.component.html',
  styleUrls: ['./watersports.component.scss']

})
export class WatersportsComponent {
  private _albums: any = [];
  showListing:boolean= true;
  showDetails:boolean= false;
  navOpen:boolean = false;

  redirectToHome() {
    // Navigate to the home component
    this.router.navigate(['/']);
  }
  
  callPhoneNumber(phoneNumber: string) {
    window.location.href = `tel:${phoneNumber}`;
  }

  openWhatsApp(phoneNumber: string) {
    // Ensure the phone number is in international format (with country code)
    const internationalNumber = phoneNumber.startsWith('+') ? phoneNumber : `+${phoneNumber}`;
    
    // Open WhatsApp with the provided number
    window.location.href = `https://wa.me/${internationalNumber}`;
  }
  filters:any = {
    search:'DIVEIN, GOA',
    founded:'2014 Jan',
    Office: 'Vasco',
    type:'Any Home'
  }
  hotels: any = [
    {
      pageUrl:'grand-island-water-sports-combo',
      name:'Scuba, Watersports & Island',
      location:'Calangute/Baina',
      actualAmount:'2999.00',
      amount:'1999.00',
      guests:'1',
      ratings:'4.9',
      img: [
        {image:'assets/watersports/W13.png', thumbImage:'assets/watersports/W13.png', caption:'watersports'}
        ],
      amenities:[
        {name:'Scuba Diving', icon:'scuba_diving'},
        {name:'Meals & Drinks', icon:'local_drink'},
        {name:'Water Sports', icon:'surfing'},
        {name:'Boat Trips', icon:'directions_boat'},
      ],
      moreamenities:[
        {name:'Videos & Photos', icon:'photos'},
        {name:'Pickup & Drop', icon:'transfer_within_a_station'},
      ],
      features:[
        {icon:'schedule', text:'6 Hrs'},
        {icon:'lunch_dining', text:'Meals'},
        {icon:'follow_the_signs', text:'Guide'},
        {icon:'local_taxi', text:'Transport'},

      ]
    },
    {
      pageUrl:'advance-water-sports-in-goa',
      name:'Advance Water Sports',
      location:'Calangute/Baina',
      actualAmount:'1800.00',
      amount:'1500.00',
      guests:'1',
      ratings:'4.8',
      img: [
        {image:'assets/watersports/E01.png', thumbImage:'assets/watersports/E01.png', caption:'watersports'},
         ],
      amenities:[
        {name:'Scuba Diving', icon:'scuba_diving'},
        {name:'Meals & Drinks', icon:'local_drink'},
        {name:'Water Sports', icon:'surfing'},
      ],
      moreamenities:[
        {name:'Videos & Photos', icon:'photos'},
        {name:'Boat Trips', icon:'directions_boat'},
        {name:'Pickup & Drop', icon:'transfer_within_a_station'},
      ],
      features:[
        {icon:'schedule', text:'4 Hrs'},
        {icon:'follow_the_signs', text:'Guide'},
        {icon:'surfing', text:'Water Sports'},
        {icon:'person', text:'10+ Yrs'},
      ]
    },
    {
      pageUrl:'basic-water-sports-in-goa',
      name:'5 Water Sports',
      location:'Calangute/Baina',
      actualAmount:'1500.00',
      amount:'1200.00',
      guests:'1',
      ratings:'4.9',
      img: [
        {image:'assets/watersports/W12.png', thumbImage:'assets/watersports/W12.png', caption:'watersports'},
         ],
      amenities:[
        {name:'Scuba Diving', icon:'scuba_diving'},
        {name:'Meals & Drinks', icon:'local_drink'},
        {name:'Water Sports', icon:'surfing'},
      ],
      moreamenities:[
        {name:'Videos & Photos', icon:'photos'},
        {name:'Boat Trips', icon:'directions_boat'},
        {name:'Pickup & Drop', icon:'transfer_within_a_station'},
      ],
      features:[
        {icon:'schedule', text:'4 Hrs'},
        {icon:'follow_the_signs', text:'Guide'},
        {icon:'surfing', text:'Water Sports'},
        {icon:'person', text:'10+ Yrs'},
      ]
    },
    {
      pageUrl:'basic-water-sports-in-goa',
      name:'Flyboarding',
      location:'Calangute',
      actualAmount:'3000.00',
      amount:'2500.00',
      guests:'1',
      ratings:'4.9',
      img: [
        {image:'assets/watersports/W14.png', thumbImage:'assets/watersports/W14.png', caption:'watersports'},
            ],
      amenities:[
        {name:'Scuba Diving', icon:'scuba_diving'},
        {name:'Meals & Drinks', icon:'local_drink'},
        {name:'Water Sports', icon:'surfing'},
      ],
      moreamenities:[
        {name:'Videos & Photos', icon:'photos'},
        {name:'Boat Trips', icon:'directions_boat'},
        {name:'Pickup & Drop', icon:'transfer_within_a_station'},
      ],
      features:[
        {icon:'schedule', text:'4 Hrs'},
        {icon:'follow_the_signs', text:'Guide'},
        {icon:'surfing', text:'Water Sports'},
        {icon:'person', text:'12+ Yrs'},
      ]
    },
    {
      pageUrl:'parasailing',
      name:'Parasailing & Jetski',
      location:'Calangute/Baina',
      actualAmount:'2000.00',
      amount:'1400.00',
      guests:'1',
      ratings:'4.9',
      img: [
        {image:'assets/watersports/W10.png', thumbImage:'assets/watersports/W10.png', caption:'watersports'},
         ],
      amenities:[
        {name:'Scuba Diving', icon:'scuba_diving'},
        {name:'Meals & Drinks', icon:'local_drink'},
        {name:'Water Sports', icon:'surfing'},
      ],
      moreamenities:[
        {name:'Videos & Photos', icon:'photos'},
        {name:'Boat Trips', icon:'directions_boat'},
        {name:'Pickup & Drop', icon:'transfer_within_a_station'},
      ],
      features:[
        {icon:'schedule', text:'4 Hrs'},
        {icon:'follow_the_signs', text:'Guide'},
        {icon:'surfing', text:'Water Sports'},
        {icon:'person', text:'10+ Yrs'},
      ]
    },
    {
      pageUrl:'/parasailing',
      name:'Parasailing',
      location:'Calangute/Baina',
      actualAmount:'1300.00',
      amount:'900.00',
      guests:'1',
      ratings:'4.9',
      img: [
        {image:'assets/watersports/02.png', thumbImage:'assets/watersports/02.png', caption:'watersports'},
        ],
      amenities:[
        {name:'Scuba Diving', icon:'scuba_diving'},
        {name:'Meals & Drinks', icon:'local_drink'},
        {name:'Water Sports', icon:'surfing'},
      ],
      moreamenities:[
        {name:'Videos & Photos', icon:'photos'},
        {name:'Boat Trips', icon:'directions_boat'},
        {name:'Pickup & Drop', icon:'transfer_within_a_station'},
      ],
      features:[
        {icon:'schedule', text:'2 Hrs'},
        {icon:'follow_the_signs', text:'Guide'},
        {icon:'surfing', text:'Water Sports'},
        {icon:'person', text:'10+ Yrs'},
      ]
    },
    {
      pageUrl:'jetski',
      name:' Jetski',
      location:'Calangute/Baina',
      actualAmount:'1000.00',
      amount:'500.00',
      guests:'1',
      ratings:'4.9',
      img: [
        {image:'assets/watersports/W08.png', thumbImage:'assets/watersports/W08.png', caption:'watersports'},
        ],
      amenities:[
        {name:'Scuba Diving', icon:'scuba_diving'},
        {name:'Meals & Drinks', icon:'local_drink'},
        {name:'Water Sports', icon:'surfing'},
      ],
      moreamenities:[
        {name:'Videos & Photos', icon:'photos'},
        {name:'Boat Trips', icon:'directions_boat'},
        {name:'Pickup & Drop', icon:'transfer_within_a_station'},
      ],
      features:[
        {icon:'schedule', text:'2 Hrs'},
        {icon:'follow_the_signs', text:'Guide'},
        {icon:'surfing', text:'Water Sports'},
        {icon:'person', text:'10+ Yrs'},
      ]
    },

  ]

  constructor(private _lightbox: Lightbox, private _service:MainService, private router: Router, private route: ActivatedRoute) {

  }

  goToDetail(hotelName: string){
    this.router.navigate([hotelName], { relativeTo: this.route });
  }

  goBack(){
    this.router.navigate(['../'], {relativeTo: this.route});
  }

  ngOnInit(){
    this._service.backToList.subscribe((res:any)=>{
      this.showListing = true;
    })
  }

  // open(index: number): void {
  //   // open lightbox
  //   this._lightbox.open(this._albums, index);
  // }

  // close(): void {
  //   // close lightbox programmatically
  //   this._lightbox.close();
  // }
}
